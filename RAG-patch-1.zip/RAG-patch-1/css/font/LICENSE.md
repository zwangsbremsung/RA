The fonts found in `5by7-webfont.woff` and `5by7-webfont.woff2` are conversions of the
free (but license unknown) 5by7 font by Peter Wiegel.

The font itself and further information may be found at
http://www.peter-wiegel.de/5by7.html